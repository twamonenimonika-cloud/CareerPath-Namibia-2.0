const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "development-secret-change-me";
const dbPath = path.join(__dirname, "data", "careerpath.db");

fs.mkdirSync(path.join(__dirname, "data"), { recursive: true });

const db = new Database(dbPath);
db.pragma("foreign_keys = ON");

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 500 }));
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'student',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS careers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 slug TEXT NOT NULL UNIQUE,
 name TEXT NOT NULL,
 icon TEXT NOT NULL,
 category TEXT NOT NULL,
 description TEXT NOT NULL,
 required_subjects TEXT NOT NULL,
 recommended_subjects TEXT NOT NULL,
 skills TEXT NOT NULL,
 jobs TEXT NOT NULL,
 pathway TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS saved_careers (
 user_id INTEGER NOT NULL,
 career_id INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (user_id, career_id),
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY(career_id) REFERENCES careers(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS quiz_results (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 results TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS opportunities (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 organisation TEXT NOT NULL,
 type TEXT NOT NULL,
 description TEXT NOT NULL,
 deadline TEXT,
 url TEXT,
 verified INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1
);
`);

const careerCount = db.prepare("SELECT COUNT(*) AS count FROM careers").get().count;
if (!careerCount) {
  const insert = db.prepare(`
    INSERT INTO careers
    (slug,name,icon,category,description,required_subjects,recommended_subjects,skills,jobs,pathway)
    VALUES (@slug,@name,@icon,@category,@description,@required_subjects,@recommended_subjects,@skills,@jobs,@pathway)
  `);

  const seed = [
    ["software-developer","Software Developer","💻","Technology","Designs and builds websites, applications and software.","Mathematics|English","Computer Studies|Physical Science","Problem solving|Programming|Logical thinking","Software Developer|Web Developer|Mobile Developer","School → Computing/IT programme → Portfolio/internship → Technology career"],
    ["medical-doctor","Medical Doctor","🩺","Health","Diagnoses illness and provides medical care.","Biology|Physical Science|Mathematics|English","Chemistry","Science|Communication|Empathy","Doctor|Medical Officer|Specialist","School → Health Sciences pathway → Clinical training → Registration requirements"],
    ["registered-nurse","Registered Nurse","🩹","Health","Provides patient care and supports healthcare teams.","Biology|English","Mathematics|Physical Science","Care|Communication|Teamwork","Registered Nurse|Community Nurse","School → Nursing pathway → Clinical training → Professional registration"],
    ["civil-engineer","Civil Engineer","🏗️","Engineering","Plans and develops infrastructure and construction projects.","Mathematics|Physical Science|English","Geography","Mathematics|Design|Problem solving","Civil Engineer|Project Engineer","School → Engineering programme → Practical training → Professional development"],
    ["teacher","Teacher","👩‍🏫","Education","Educates and supports learners in schools and communities.","English","Mathematics|History|Geography","Communication|Patience|Leadership","Teacher|Tutor|Education Officer","School → Education programme → Teaching practice → Education career"],
    ["accountant","Accountant","📊","Business","Manages financial information and supports business decisions.","Accounting|Mathematics|English","Economics|Business Studies","Numeracy|Analysis|Attention to detail","Accountant|Financial Officer|Auditor","School → Accounting/Finance pathway → Practical experience/professional requirements"],
    ["agricultural-scientist","Agricultural Scientist","🌾","Agriculture","Uses science and research to improve food production and farming.","Biology|Agriculture|English","Mathematics|Geography","Science|Research|Problem solving","Agricultural Scientist|Agricultural Officer|Farm Manager","School → Agriculture/Science programme → Research or industry pathway"],
    ["tourism-manager","Tourism Manager","✈️","Tourism","Plans and manages travel, tourism and hospitality services.","English","Geography|Business Studies|History","Customer service|Planning|Communication","Tourism Manager|Travel Consultant|Lodge Manager","School → Tourism/Hospitality programme → Industry experience"],
    ["legal-professional","Legal Professional","⚖️","Law","Works with legal systems, contracts, compliance and justice.","English","History|Economics|Business Studies","Research|Reasoning|Communication","Legal Practitioner|Legal Advisor|Compliance Officer","School → Law pathway → Practical/professional requirements"],
    ["entrepreneur","Entrepreneur","🚀","Business","Builds businesses and develops solutions to problems.","English","Business Studies|Accounting|Economics","Leadership|Creativity|Decision making","Founder|Business Owner|Consultant","School/skills → Business development → Launch and grow venture"]
  ];

  const tx = db.transaction(() => {
    seed.forEach(r => insert.run({
      slug:r[0], name:r[1], icon:r[2], category:r[3], description:r[4],
      required_subjects:r[5], recommended_subjects:r[6], skills:r[7], jobs:r[8], pathway:r[9]
    }));
  });
  tx();
}

const admin = db.prepare("SELECT id FROM users WHERE email=?").get("admin@careerpath.na");
if (!admin) {
  const hash = bcrypt.hashSync("ChangeMe123!", 12);
  db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
    .run("CareerPath Administrator","admin@careerpath.na",hash,"admin");
}

const oppCount = db.prepare("SELECT COUNT(*) AS count FROM opportunities").get().count;
if (!oppCount) {
  db.prepare(`INSERT INTO opportunities(title,organisation,type,description,deadline,url,verified)
  VALUES(?,?,?,?,?,?,?)`).run(
    "Scholarship & Opportunity Board",
    "CareerPath Namibia",
    "Information",
    "This board is ready for verified scholarships, internships and opportunities. Only publish externally verified opportunities before production use.",
    null, null, 0
  );
}

function token(user) {
  return jwt.sign({ id:user.id, role:user.role, name:user.name }, JWT_SECRET, { expiresIn:"7d" });
}

function auth(req,res,next) {
  const header = req.headers.authorization || "";
  const value = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!value) return res.status(401).json({ error:"Authentication required" });
  try { req.user = jwt.verify(value, JWT_SECRET); next(); }
  catch { return res.status(401).json({ error:"Invalid or expired session" }); }
}

function adminOnly(req,res,next) {
  if (req.user.role !== "admin") return res.status(403).json({ error:"Administrator access required" });
  next();
}

function safeCareer(row) {
  return {
    ...row,
    required_subjects: row.required_subjects.split("|").filter(Boolean),
    recommended_subjects: row.recommended_subjects.split("|").filter(Boolean),
    skills: row.skills.split("|").filter(Boolean),
    jobs: row.jobs.split("|").filter(Boolean)
  };
}

app.post("/api/auth/register", (req,res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password || password.length < 8)
    return res.status(400).json({ error:"Name, valid email and password of at least 8 characters are required." });

  try {
    const hash = bcrypt.hashSync(password, 12);
    const result = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")
      .run(name.trim(), email.trim().toLowerCase(), hash, "student");
    const user = { id:result.lastInsertRowid, name:name.trim(), role:"student" };
    res.status(201).json({ token:token(user), user });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error:"An account with this email already exists." });
    res.status(500).json({ error:"Could not create account." });
  }
});

app.post("/api/auth/login", (req,res) => {
  const { email,password } = req.body || {};
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(String(email||"").trim().toLowerCase());
  if (!user || !bcrypt.compareSync(password||"", user.password_hash))
    return res.status(401).json({ error:"Incorrect email or password." });
  res.json({ token:token(user), user:{ id:user.id,name:user.name,email:user.email,role:user.role } });
});

app.get("/api/careers", (req,res) => {
  const { q="", category="" } = req.query;
  let rows = db.prepare("SELECT * FROM careers ORDER BY name").all().map(safeCareer);
  const query = q.toLowerCase();
  if (query) rows = rows.filter(c => `${c.name} ${c.description} ${c.category}`.toLowerCase().includes(query));
  if (category) rows = rows.filter(c => c.category === category);
  res.json(rows);
});

app.get("/api/careers/:slug", (req,res) => {
  const row = db.prepare("SELECT * FROM careers WHERE slug=?").get(req.params.slug);
  if (!row) return res.status(404).json({ error:"Career not found" });
  res.json(safeCareer(row));
});

app.get("/api/categories", (req,res) => {
  res.json(db.prepare("SELECT DISTINCT category FROM careers ORDER BY category").all().map(r=>r.category));
});

app.get("/api/me/saved", auth, (req,res) => {
  const rows = db.prepare(`
    SELECT c.* FROM saved_careers s JOIN careers c ON c.id=s.career_id
    WHERE s.user_id=? ORDER BY s.created_at DESC`).all(req.user.id).map(safeCareer);
  res.json(rows);
});

app.post("/api/me/saved/:id", auth, (req,res) => {
  try {
    db.prepare("INSERT OR IGNORE INTO saved_careers(user_id,career_id) VALUES(?,?)").run(req.user.id, req.params.id);
    res.json({ ok:true });
  } catch { res.status(400).json({ error:"Could not save career." }); }
});

app.delete("/api/me/saved/:id", auth, (req,res) => {
  db.prepare("DELETE FROM saved_careers WHERE user_id=? AND career_id=?").run(req.user.id, req.params.id);
  res.json({ ok:true });
});

app.post("/api/quiz-results", auth, (req,res) => {
  db.prepare("INSERT INTO quiz_results(user_id,results) VALUES(?,?)").run(req.user.id, JSON.stringify(req.body.results||[]));
  res.json({ ok:true });
});

app.get("/api/opportunities", (req,res) => {
  res.json(db.prepare("SELECT * FROM opportunities WHERE active=1 ORDER BY id DESC").all());
});

app.get("/api/admin/stats", auth, adminOnly, (req,res) => {
  res.json({
    users: db.prepare("SELECT COUNT(*) c FROM users WHERE role='student'").get().c,
    careers: db.prepare("SELECT COUNT(*) c FROM careers").get().c,
    saved: db.prepare("SELECT COUNT(*) c FROM saved_careers").get().c,
    opportunities: db.prepare("SELECT COUNT(*) c FROM opportunities WHERE active=1").get().c
  });
});

app.post("/api/admin/opportunities", auth, adminOnly, (req,res) => {
  const { title, organisation, type, description, deadline, url, verified } = req.body || {};
  if (!title || !organisation || !type || !description) return res.status(400).json({ error:"Please complete all required fields." });
  db.prepare(`INSERT INTO opportunities(title,organisation,type,description,deadline,url,verified)
    VALUES(?,?,?,?,?,?,?)`).run(title,organisation,type,description,deadline||null,url||null,verified?1:0);
  res.status(201).json({ ok:true });
});

app.get("*", (_,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, () => console.log(`CareerPath Namibia running on http://localhost:${PORT}`));
