# CareerPath Namibia

A full-stack career guidance portal for Namibian Grade 10–12 learners.

## Included
- Student registration and login
- Secure password hashing
- JWT authentication
- SQLite database
- Career discovery quiz
- Subject matcher
- Career explorer and filters
- Saved careers
- Personal dashboard
- Grade/points calculator
- Study pathways
- Scholarships/opportunities board
- Admin dashboard and management endpoints
- Responsive mobile-first interface
- Security headers and API rate limiting

## Run locally

1. Install Node.js 18+.
2. Open a terminal inside this folder.
3. Run:
   npm install
4. Copy `.env.example` to `.env` and change `JWT_SECRET`.
5. Run:
   npm start
6. Open:
   http://localhost:3000

## Demo admin
Email: admin@careerpath.na
Password: ChangeMe123!

Change this password immediately in a real deployment.

## Important
Career and institution information in this starter project is guidance data, not an official admissions database. Before publishing nationally, connect verified content workflows and obtain current programme requirements directly from institutions and authorised sources.
